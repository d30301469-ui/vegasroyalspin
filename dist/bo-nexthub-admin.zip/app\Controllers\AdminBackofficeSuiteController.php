<?php

declare(strict_types=1);

final class AdminBackofficeSuiteController extends AdminController
{
    public function index(): void
    {
        $this->requirePermission('dashboard');

        $modules = $this->suiteModules();
        $readyCount = count(array_filter($modules, static fn (array $module): bool => ($module['status'] ?? '') === 'ready'));
        $partialCount = count(array_filter($modules, static fn (array $module): bool => ($module['status'] ?? '') === 'partial'));
        $plannedCount = count(array_filter($modules, static fn (array $module): bool => ($module['status'] ?? '') === 'planned'));

        $this->view('backoffice-suite/index', [
            'title' => 'Backoffice Suite',
            'active' => 'backoffice-suite',
            'crumbs' => 'Admin | Backoffice Suite',
            'modules' => $modules,
            'referenceScreens' => $this->referenceScreens(),
            'summary' => [
                ['label' => 'Referans ekran', 'value' => count($this->referenceScreens()), 'class' => 'primary'],
                ['label' => 'Hazır modül', 'value' => $readyCount, 'class' => 'success'],
                ['label' => 'Kısmi modül', 'value' => $partialCount, 'class' => 'warning'],
                ['label' => 'Planlanan modül', 'value' => $plannedCount, 'class' => 'purple'],
            ],
            'liveMetrics' => [
                ['label' => 'Toplam üye', 'value' => $this->scalar('SELECT COUNT(*) FROM users')],
                ['label' => 'Bekleyen çekim', 'value' => $this->scalar("SELECT COUNT(*) FROM megapayz_transactions WHERE type = 'withdraw' AND status = 'pending'")],
                ['label' => 'Bekleyen KYC', 'value' => $this->scalar("SELECT COUNT(*) FROM kyc_requests WHERE status = 'pending'")],
                ['label' => 'Açık destek', 'value' => $this->scalar("SELECT COUNT(*) FROM support_tickets WHERE status IN ('open','answered')")],
                ['label' => 'AML uyarısı', 'value' => $this->scalar("SELECT COUNT(*) FROM aml_alerts WHERE status = 'open'")],
                ['label' => 'Aktif içerik', 'value' => $this->scalar("SELECT COUNT(*) FROM promotions WHERE status IN ('active', 'published', '1')") + $this->scalar("SELECT COUNT(*) FROM sliders WHERE status IN ('active', 'published', '1')")],
            ],
        ]);
    }

    private function suiteModules(): array
    {
        return [
            [
                'title' => 'Real-Time Dashboard',
                'status' => 'ready',
                'statusText' => 'Hazır',
                'description' => 'Canlı trafik, finans, üye ve operasyon kuyrukları tek ana ekranda özetlenir.',
                'reference' => 'dashboard-full.webp, hero-dashboard.webp',
                'localRoute' => '/dashboard',
                'localLabel' => 'Dashboard',
                'nextStep' => 'Chart widgetlarını provider GGR ve bonus metrikleriyle genişlet.',
            ],
            [
                'title' => 'Dashboard Charts',
                'status' => 'partial',
                'statusText' => 'Kısmi',
                'description' => 'Finans, ziyaret ve oyun özetleri mevcut; daha ayrıntılı GGR/RTP grafik ekranı ayrılmalı.',
                'reference' => 'finance-report.webp',
                'localRoute' => '/dashboard',
                'localLabel' => 'Dashboard özetleri',
                'nextStep' => 'Rapor controller route ve sidebar girişleri tamamlanmalı.',
            ],
            [
                'title' => 'Player Management',
                'status' => 'ready',
                'statusText' => 'Hazır',
                'description' => 'Üye listesi, detay, bakiye düzenleme, KYC, bonus talepleri ve dondurulan hesaplar mevcut.',
                'reference' => 'players.webp',
                'localRoute' => '/module?key=users',
                'localLabel' => 'Üyeler',
                'nextStep' => 'Üye detayına risk/segment notları eklenebilir.',
            ],
            [
                'title' => 'Player GeoMap',
                'status' => 'partial',
                'statusText' => 'Kısmi',
                'description' => 'Visitor log lokasyon verisi okunuyor; oyuncu listesiyle entegre harita görünümü ayrılaştırılmalı.',
                'reference' => 'players-geomap.webp',
                'localRoute' => '/dashboard',
                'localLabel' => 'Trafik ülkeleri',
                'nextStep' => 'Harita route bağlantısını oyuncu IP/GeoIP kayıtlarıyla birleştir.',
            ],
            [
                'title' => 'Advanced Filtering',
                'status' => 'partial',
                'statusText' => 'Kısmi',
                'description' => 'Generic table arama var; referanstaki gibi çok alanlı tarih, KYC, para birimi ve partner filtreleri eklenmeli.',
                'reference' => 'players-filter.webp',
                'localRoute' => '/module?key=users',
                'localLabel' => 'Üye tablosu',
                'nextStep' => 'AdminTableRepository için kolon bazlı filter pipeline kurulmalı.',
            ],
            [
                'title' => 'Risk Analysis',
                'status' => 'planned',
                'statusText' => 'Planlandı',
                'description' => 'Ban, freeze, KYC ve provider logları var; bunları birleştiren skor ve RTP/GGR risk paneli eksik.',
                'reference' => 'player-risk-high.webp',
                'localRoute' => '/module?key=frozen-accounts',
                'localLabel' => 'Dondurulan hesaplar',
                'nextStep' => 'Provider bazlı oyuncu P/L, RTP sapması ve alarm kuralları için özel controller yaz.',
            ],
            [
                'title' => 'Bonus Engine',
                'status' => 'partial',
                'statusText' => 'Kısmi',
                'description' => 'Aktif bonus, bonus talebi, promocode ve Drakon freespin kampanyaları mevcut.',
                'reference' => 'bonus-wizard1.webp',
                'localRoute' => '/module?key=bonus-claims',
                'localLabel' => 'Bonus talepleri',
                'nextStep' => 'Deposit/loss/freespin/cash wizard akışını tek form ekranında birleştir.',
            ],
            [
                'title' => 'Reports & Analytics',
                'status' => 'partial',
                'statusText' => 'Kısmi',
                'description' => 'Dashboard ve report controller veri üretiyor; menü ve net GGR/provider raporları tamamlanmalı.',
                'reference' => 'finance-report.webp',
                'localRoute' => '/dashboard',
                'localLabel' => 'Finans özeti',
                'nextStep' => 'Net GGR, provider maliyeti ve ödeme dönüşüm raporlarını ayrı sekmeler yap.',
            ],
            [
                'title' => 'CMS & Content',
                'status' => 'ready',
                'statusText' => 'Hazır',
                'description' => 'Promosyon, slider, auth slider, duyuru, homepage section, footer ve mobil menü yönetimi mevcut.',
                'reference' => 'cms-banners.webp',
                'localRoute' => '/module?key=promotions',
                'localLabel' => 'Promosyonlar',
                'nextStep' => 'Media library ve popup/story içerikleri için ek modül aç.',
            ],
            [
                'title' => 'Settings & Security',
                'status' => 'ready',
                'statusText' => 'Hazır',
                'description' => 'Adminler, yetkiler, oturumlar, loglar, site ayarları ve provider ayarları yönetiliyor.',
                'reference' => 'settings-components.webp',
                'localRoute' => '/permissions',
                'localLabel' => 'Admin yetkileri',
                'nextStep' => '2FA zorunluluğu ve IP whitelist ekranı ayrı güvenlik kartına taşınabilir.',
            ],
            [
                'title' => 'Domain Management',
                'status' => 'partial',
                'statusText' => 'Kısmi',
                'description' => 'Frontend/backend URL ve allowed host ayarları site ayarlarında tutuluyor; Cloudflare/DNS durumu yok.',
                'reference' => 'domains-management.webp',
                'localRoute' => '/site-settings',
                'localLabel' => 'Site ayarları',
                'nextStep' => 'Domain, SSL, DNS ve Cloudflare status alanları için özel tablo ve ekran ekle.',
            ],
        ];
    }

    private function referenceScreens(): array
    {
        return [
            ['name' => 'Hero dashboard', 'file' => 'hero-dashboard.webp', 'area' => 'Dashboard vitrin'],
            ['name' => 'Dashboard full', 'file' => 'dashboard-full.webp', 'area' => 'Canlı KPI ve grafikler'],
            ['name' => 'Players', 'file' => 'players.webp', 'area' => 'Üye yönetimi'],
            ['name' => 'Players filter', 'file' => 'players-filter.webp', 'area' => 'Gelişmiş filtre'],
            ['name' => 'Players geomap', 'file' => 'players-geomap.webp', 'area' => 'GeoIP harita'],
            ['name' => 'Player risk high', 'file' => 'player-risk-high.webp', 'area' => 'Risk analizi'],
            ['name' => 'Bonus wizard', 'file' => 'bonus-wizard1.webp', 'area' => 'Bonus motoru'],
            ['name' => 'Finance report', 'file' => 'finance-report.webp', 'area' => 'Raporlama'],
            ['name' => 'CMS banners', 'file' => 'cms-banners.webp', 'area' => 'CMS ve medya'],
            ['name' => 'Settings components', 'file' => 'settings-components.webp', 'area' => 'Ayarlar ve güvenlik'],
            ['name' => 'Domains management', 'file' => 'domains-management.webp', 'area' => 'Domain yönetimi'],
        ];
    }

    private function scalar(string $sql): int
    {
        try {
            return (int) AdminDatabase::pdo()->query($sql)->fetchColumn();
        } catch (Throwable) {
            return 0;
        }
    }
}
